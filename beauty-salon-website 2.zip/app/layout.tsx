import type { Metadata, Viewport } from 'next'
import { Cormorant_Garamond, Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const cormorant = Cormorant_Garamond({ 
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-cormorant"
})

const inter = Inter({ 
  subsets: ["latin"],
  variable: "--font-inter"
})

export const metadata: Metadata = {
  title: 'Naturallook Family Salon & Bridal Studio | Luxury Beauty in Hosur',
  description: 'Experience Hosur\'s premium family salon with expert bridal makeup, Korean hair wash, professional grooming & luxury beauty care. 4.9★ rated with 2700+ happy clients.',
  keywords: 'salon hosur, bridal makeup hosur, korean hair wash, family salon, beauty salon tamil nadu, bridal studio',
  generator: 'v0.app',
  openGraph: {
    title: 'Naturallook Family Salon & Bridal Studio',
    description: 'Luxury Beauty. Timeless Confidence. Experience premium beauty care in Hosur.',
    type: 'website',
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#1a1a1a',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-background">
      <body className={`${cormorant.variable} ${inter.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
