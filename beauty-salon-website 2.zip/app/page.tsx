import { Navigation } from "@/components/navigation"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { ServicesSection } from "@/components/services-section"
import { KoreanHairWashSection } from "@/components/korean-hairwash-section"
import { BridalSection } from "@/components/bridal-section"
import { WhyChooseUsSection } from "@/components/why-choose-us-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { GallerySection } from "@/components/gallery-section"
import { BookingSection } from "@/components/booking-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"
import { WhatsAppButton } from "@/components/whatsapp-button"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <ServicesSection />
      <KoreanHairWashSection />
      <BridalSection />
      <WhyChooseUsSection />
      <TestimonialsSection />
      <GallerySection />
      <BookingSection />
      <ContactSection />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
