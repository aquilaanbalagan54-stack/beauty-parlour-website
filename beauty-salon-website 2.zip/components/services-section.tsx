"use client"

import { motion } from "framer-motion"
import { Scissors, Sparkles, Heart, User, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const serviceCategories = [
  {
    icon: Scissors,
    title: "Hair Services",
    services: [
      "Haircut & Styling",
      "Hair Spa",
      "Hair Coloring",
      "Smoothening",
      "Keratin Treatment",
      "Korean Hair Wash",
      "Scalp Treatments",
    ],
  },
  {
    icon: Sparkles,
    title: "Beauty Services",
    services: [
      "Facial Treatments",
      "Cleanup",
      "Waxing",
      "Threading",
      "Bleach",
      "Skin Glow Treatments",
    ],
  },
  {
    icon: Heart,
    title: "Bridal Services",
    services: [
      "Bridal Makeup",
      "Reception Makeup",
      "Engagement Look",
      "Saree Draping",
      "Bridal Hair Styling",
      "HD & Airbrush Makeup",
    ],
  },
  {
    icon: User,
    title: "Grooming Services",
    services: [
      "Beard Styling",
      "Men's Grooming",
      "Head Massage",
      "Premium Packages",
    ],
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-24 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl" />
      <div className="absolute top-1/2 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span 
            className="text-primary text-sm tracking-widest uppercase mb-4 block"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            Our Services
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-light mb-6">
            <span className="text-gradient-gold">Premium Beauty</span>
            <br />
            <span className="text-foreground">Services</span>
          </h2>
          <p 
            className="text-muted-foreground max-w-2xl mx-auto"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            From head-to-toe pampering to bridal transformations, experience luxury beauty care tailored just for you.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {serviceCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 * index }}
              className="glass rounded-3xl p-6 hover:border-primary/40 transition-all duration-500 group"
            >
              {/* Icon */}
              <div className="w-14 h-14 rounded-2xl burgundy-gradient flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <category.icon className="w-7 h-7 text-primary-foreground" />
              </div>

              {/* Title */}
              <h3 className="text-xl font-medium text-foreground mb-4">{category.title}</h3>

              {/* Services list */}
              <ul className="space-y-2 mb-6">
                {category.services.map((service) => (
                  <li 
                    key={service} 
                    className="text-muted-foreground text-sm flex items-center gap-2"
                    style={{ fontFamily: 'Inter, sans-serif' }}
                  >
                    <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                    {service}
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <Button
                variant="ghost"
                className="w-full justify-between text-primary hover:text-primary hover:bg-primary/10 group/btn"
                asChild
              >
                <a href="#booking">
                  <span style={{ fontFamily: 'Inter, sans-serif' }}>Book Now</span>
                  <ChevronRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </a>
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
