"use client"

import { motion } from "framer-motion"
import { Sparkles, Heart, Shield, Star, Leaf, Users } from "lucide-react"

const features = [
  { icon: Sparkles, title: "Professional Stylists", desc: "Expert beauticians with years of experience" },
  { icon: Heart, title: "Premium Products", desc: "Only the finest beauty products used" },
  { icon: Shield, title: "Hygienic Environment", desc: "Strict hygiene protocols maintained" },
  { icon: Star, title: "Bridal Specialists", desc: "Transform your special day look" },
  { icon: Leaf, title: "Korean Hair Wash", desc: "Viral relaxation experience" },
  { icon: Users, title: "Family Friendly", desc: "Services for all family members" },
]

export function AboutSection() {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span 
              className="text-primary text-sm tracking-widest uppercase mb-4 block"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              About Us
            </span>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-light mb-6">
              <span className="text-gradient-gold">Where Beauty</span>
              <br />
              Meets Excellence
            </h2>
            <p 
              className="text-muted-foreground text-lg leading-relaxed mb-8"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              {"At Naturallook Family Salon & Bridal Studio, beauty is more than a service — it's an experience. From rejuvenating Korean hair washes to bridal transformations and luxury grooming, our expert stylists and beauticians are dedicated to helping every client feel confident, refreshed, and radiant."}
            </p>
            <p 
              className="text-muted-foreground leading-relaxed"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              {"Located in the heart of Hosur, we've served over 2,700 happy clients with our premium beauty services. Our women-owned salon takes pride in creating a welcoming, inclusive environment where everyone can experience luxury self-care."}
            </p>
          </motion.div>

          {/* Features Grid */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="grid grid-cols-2 gap-4"
          >
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 * index }}
                className="glass p-6 rounded-2xl hover:border-primary/40 transition-all duration-300 group"
              >
                <feature.icon className="w-8 h-8 text-primary mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-foreground font-medium mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                  {feature.desc}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}
