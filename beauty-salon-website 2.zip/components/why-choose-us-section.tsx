"use client"

import { motion } from "framer-motion"
import { Star, Users, Award, Clock } from "lucide-react"
import { useEffect, useState } from "react"

const stats = [
  { icon: Star, value: 4.9, suffix: "★", label: "Customer Rating" },
  { icon: Users, value: 2707, suffix: "+", label: "Happy Clients" },
  { icon: Award, value: 10, suffix: "+", label: "Years Experience" },
  { icon: Clock, value: 365, suffix: "", label: "Days Open" },
]

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0)
  const [hasAnimated, setHasAnimated] = useState(false)

  useEffect(() => {
    if (hasAnimated) return
    
    const duration = 2000
    const steps = 60
    const increment = value / steps
    let current = 0

    const timer = setInterval(() => {
      current += increment
      if (current >= value) {
        setCount(value)
        clearInterval(timer)
        setHasAnimated(true)
      } else {
        setCount(Math.floor(current * 10) / 10)
      }
    }, duration / steps)

    return () => clearInterval(timer)
  }, [value, hasAnimated])

  return (
    <span className="text-gradient-gold">
      {count.toLocaleString()}{suffix}
    </span>
  )
}

export function WhyChooseUsSection() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/10 via-background to-background" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span 
            className="text-primary text-sm tracking-widest uppercase mb-4 block"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            Why Choose Us
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-light mb-6">
            <span className="text-gradient-gold">Trusted by</span>
            <br />
            <span className="text-foreground">Thousands</span>
          </h2>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ delay: 0.1 * index }}
              className="glass rounded-2xl p-6 text-center hover:border-primary/40 transition-all duration-300"
            >
              <stat.icon className="w-8 h-8 text-primary mx-auto mb-4" />
              <div className="text-4xl md:text-5xl font-light mb-2">
                <AnimatedCounter value={stat.value} suffix={stat.suffix} />
              </div>
              <p className="text-muted-foreground text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                {stat.label}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Additional highlights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-4 mt-12"
        >
          {[
            "Women-Owned Salon",
            "LGBTQ+ Friendly",
            "Expert Stylists",
            "Luxury Ambience",
            "Hygienic Care",
            "Personalized Service",
          ].map((highlight, index) => (
            <motion.div
              key={highlight}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.05 * index }}
              className="glass px-5 py-2.5 rounded-full border-primary/20 hover:border-primary/50 transition-colors"
            >
              <span className="text-foreground/90 text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                {highlight}
              </span>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
