"use client"

import { motion } from "framer-motion"
import { Star, Phone, MessageCircle, Sparkles, Award, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden luxury-gradient">
      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-primary/30 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 5 + Math.random() * 5,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>

      {/* Warm glow orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[oklch(0.88_0.06_15/0.5)] rounded-full blur-3xl glow-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-[oklch(0.72_0.12_55/0.2)] rounded-full blur-3xl glow-pulse" style={{ animationDelay: '1.5s' }} />
      <div className="absolute top-1/2 right-1/3 w-64 h-64 bg-[oklch(0.75_0.1_350/0.2)] rounded-full blur-3xl glow-pulse" style={{ animationDelay: '3s' }} />

      <div className="container mx-auto px-4 py-20 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-4xl mx-auto"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full mb-8"
          >
            <Award className="w-4 h-4 text-[oklch(0.72_0.12_55)]" />
            <span className="text-sm text-foreground/80">Women-Owned Salon</span>
            <span className="w-1 h-1 bg-primary rounded-full" />
            <Heart className="w-4 h-4 text-[oklch(0.75_0.1_350)]" />
            <span className="text-sm text-foreground/80">LGBTQ+ Friendly</span>
          </motion.div>

          {/* Main heading */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="text-5xl md:text-7xl lg:text-8xl font-light tracking-tight mb-6"
          >
            <span className="text-gradient-gold">Luxury Beauty.</span>
            <br />
            <span className="text-foreground">Timeless Confidence.</span>
          </motion.h1>

          {/* Subheading */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed font-sans"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            {"Experience Hosur's Premium Family Salon & Bridal Studio with Expert Beauty Care, Korean Hair Wash, Bridal Transformations & Professional Grooming."}
          </motion.p>

          {/* Rating badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6 }}
            className="flex items-center justify-center gap-6 mb-10"
          >
            <div className="flex items-center gap-2 glass px-4 py-2 rounded-full">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[oklch(0.72_0.12_55)] text-[oklch(0.72_0.12_55)]" />
                ))}
              </div>
              <span className="text-foreground font-medium">4.9</span>
            </div>
            <div className="glass px-4 py-2 rounded-full">
              <span className="text-foreground/80">2,700+ Happy Clients</span>
            </div>
          </motion.div>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              className="burgundy-gradient text-primary-foreground px-8 py-6 text-lg rounded-full glow-burgundy hover:scale-105 transition-transform duration-300"
              asChild
            >
              <a href="#booking">
                <Sparkles className="w-5 h-5 mr-2" />
                Book Appointment
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary/50 text-foreground px-8 py-6 text-lg rounded-full hover:bg-primary/10 hover:border-primary transition-all duration-300"
              asChild
            >
              <a href="#services">Explore Services</a>
            </Button>
            <Button
              size="lg"
              variant="ghost"
              className="text-foreground px-8 py-6 text-lg rounded-full hover:bg-secondary transition-all duration-300"
              asChild
            >
              <a href="https://wa.me/919688266300" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-5 h-5 mr-2" />
                WhatsApp Now
              </a>
            </Button>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-6 h-10 border-2 border-primary/50 rounded-full flex justify-center pt-2"
        >
          <div className="w-1.5 h-3 bg-primary rounded-full" />
        </motion.div>
      </motion.div>
    </section>
  )
}
