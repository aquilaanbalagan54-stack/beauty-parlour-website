"use client"

import { motion } from "framer-motion"
import { Droplets, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

export function KoreanHairWashSection() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background with water ripple effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/20 to-background" />
      
      {/* Animated circles for water effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute border border-primary/20 rounded-full"
            style={{
              width: `${200 + i * 100}px`,
              height: `${200 + i * 100}px`,
              left: '50%',
              top: '50%',
              transform: 'translate(-50%, -50%)',
            }}
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.3, 0, 0.3],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              delay: i * 0.8,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            {/* Badge */}
            <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full mb-8">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm text-foreground/80" style={{ fontFamily: 'Inter, sans-serif' }}>
                Trending Experience
              </span>
            </div>

            {/* Icon */}
            <motion.div
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, type: "spring" }}
              className="w-24 h-24 mx-auto rounded-full burgundy-gradient flex items-center justify-center mb-8 glow-burgundy"
            >
              <Droplets className="w-12 h-12 text-primary-foreground" />
            </motion.div>

            {/* Heading */}
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-light mb-6">
              <span className="text-gradient-gold">Experience the Viral</span>
              <br />
              <span className="text-foreground">Korean Hair Wash</span>
            </h2>

            {/* Description */}
            <p 
              className="text-muted-foreground text-lg md:text-xl leading-relaxed max-w-2xl mx-auto mb-10"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Relax, refresh, and rejuvenate with our signature Korean hair wash experience featuring deep cleansing, scalp massage, nourishment, and luxurious hair care rituals.
            </p>

            {/* Benefits */}
            <div className="flex flex-wrap justify-center gap-4 mb-10">
              {["Deep Cleansing", "Scalp Massage", "Hair Nourishment", "Relaxation Therapy"].map((benefit, index) => (
                <motion.div
                  key={benefit}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className="glass px-6 py-3 rounded-full"
                >
                  <span className="text-foreground/90" style={{ fontFamily: 'Inter, sans-serif' }}>
                    {benefit}
                  </span>
                </motion.div>
              ))}
            </div>

            {/* CTA */}
            <Button
              size="lg"
              className="burgundy-gradient text-primary-foreground px-10 py-6 text-lg rounded-full glow-burgundy hover:scale-105 transition-transform duration-300"
              asChild
            >
              <a href="#booking">
                Book Korean Hair Wash
              </a>
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
