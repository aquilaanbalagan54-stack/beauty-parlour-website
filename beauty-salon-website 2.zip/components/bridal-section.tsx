"use client"

import { motion } from "framer-motion"
import { Crown, Sparkles, Heart, Star } from "lucide-react"
import { Button } from "@/components/ui/button"

const bridalServices = [
  { title: "Bridal Makeup", desc: "Complete bridal transformation" },
  { title: "Reception Look", desc: "Glamorous evening styling" },
  { title: "Engagement Styling", desc: "Elegant engagement look" },
  { title: "Saree Draping", desc: "Perfect saree styling" },
  { title: "Bridal Hair", desc: "Stunning hair designs" },
  { title: "HD Makeup", desc: "Flawless HD finish" },
]

export function BridalSection() {
  return (
    <section id="bridal" className="py-24 relative overflow-hidden">
      {/* Luxurious background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      
      {/* Floating shimmer particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-primary/40 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -50, 0],
              opacity: [0, 1, 0],
              scale: [0, 1.5, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 3,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full mb-8">
            <Crown className="w-4 h-4 text-primary" />
            <span className="text-sm text-foreground/80" style={{ fontFamily: 'Inter, sans-serif' }}>
              Bridal Studio
            </span>
          </div>

          <h2 className="text-4xl md:text-5xl lg:text-6xl font-light mb-6">
            <span className="text-gradient-gold">Your Dream Bridal Look</span>
            <br />
            <span className="text-foreground">Begins Here</span>
          </h2>
          <p 
            className="text-muted-foreground max-w-2xl mx-auto text-lg"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            {"Make your special day unforgettable with our expert bridal makeup artists. From traditional elegance to contemporary glamour, we create looks that capture your unique beauty."}
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto mb-12">
          {bridalServices.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 * index }}
              className="glass rounded-2xl p-6 text-center hover:border-primary/40 transition-all duration-300 group"
            >
              <div className="w-12 h-12 mx-auto rounded-xl burgundy-gradient flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                {index % 3 === 0 ? (
                  <Crown className="w-6 h-6 text-primary-foreground" />
                ) : index % 3 === 1 ? (
                  <Sparkles className="w-6 h-6 text-primary-foreground" />
                ) : (
                  <Heart className="w-6 h-6 text-primary-foreground" />
                )}
              </div>
              <h3 className="text-lg font-medium text-foreground mb-2">{service.title}</h3>
              <p className="text-muted-foreground text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Button
            size="lg"
            className="burgundy-gradient text-primary-foreground px-10 py-6 text-lg rounded-full glow-burgundy hover:scale-105 transition-transform duration-300"
            asChild
          >
            <a href="#booking">
              <Crown className="w-5 h-5 mr-2" />
              Book Bridal Consultation
            </a>
          </Button>
        </motion.div>
      </div>
    </section>
  )
}
