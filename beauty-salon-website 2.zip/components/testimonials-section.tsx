"use client"

import { motion } from "framer-motion"
import { Star, Quote } from "lucide-react"
import { useState, useEffect } from "react"

const testimonials = [
  {
    name: "Priya Sharma",
    role: "Bride",
    content: "I visited for my bridal makeup and the experience was absolutely magical. The team understood exactly what I wanted and made me feel like a princess on my special day.",
    rating: 5,
  },
  {
    name: "Anjali Reddy",
    role: "Regular Client",
    content: "Very good ambience with highly skilled staff. Best place for grooming in Hosur. The Korean hair wash is so relaxing and refreshing - I'm addicted!",
    rating: 5,
  },
  {
    name: "Meera Krishnan",
    role: "Hair Spa Client",
    content: "I visited for a hair spa treatment and the experience was absolutely amazing. The ambience was calming and professional. My hair has never felt better!",
    rating: 5,
  },
  {
    name: "Deepa Venkat",
    role: "Bridal Party",
    content: "The entire bridal party got ready here and everyone looked stunning. The makeup artists are true professionals who know how to enhance natural beauty.",
    rating: 5,
  },
  {
    name: "Kavitha R",
    role: "Facial Treatment",
    content: "The facial treatment was incredible. My skin is glowing! The staff is so friendly and they use only premium products. Highly recommend!",
    rating: 5,
  },
  {
    name: "Lakshmi Devi",
    role: "Family Client",
    content: "We bring the whole family here. From haircuts for the kids to my husband's grooming and my spa treatments - they take care of everyone beautifully.",
    rating: 5,
  },
]

export function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span 
            className="text-primary text-sm tracking-widest uppercase mb-4 block"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            Testimonials
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-light mb-6">
            <span className="text-gradient-gold">Client</span>
            <br />
            <span className="text-foreground">Love Stories</span>
          </h2>
        </motion.div>

        {/* Featured testimonial */}
        <div className="max-w-4xl mx-auto mb-12">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass rounded-3xl p-8 md:p-12 text-center relative"
          >
            <Quote className="w-12 h-12 text-primary/30 absolute top-8 left-8" />
            
            <div className="flex justify-center gap-1 mb-6">
              {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-primary text-primary" />
              ))}
            </div>

            <p 
              className="text-xl md:text-2xl text-foreground/90 leading-relaxed mb-8"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              {`"${testimonials[currentIndex].content}"`}
            </p>

            <div>
              <p className="text-foreground font-medium text-lg">
                {testimonials[currentIndex].name}
              </p>
              <p className="text-muted-foreground text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                {testimonials[currentIndex].role}
              </p>
            </div>
          </motion.div>
        </div>

        {/* Navigation dots */}
        <div className="flex justify-center gap-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === currentIndex 
                  ? "w-8 bg-primary" 
                  : "bg-primary/30 hover:bg-primary/50"
              }`}
              aria-label={`Go to testimonial ${index + 1}`}
            />
          ))}
        </div>

        {/* Mini testimonials grid */}
        <div className="grid md:grid-cols-3 gap-4 mt-16">
          {testimonials.slice(0, 3).map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 * index }}
              className="glass rounded-2xl p-6 hover:border-primary/40 transition-all duration-300"
            >
              <div className="flex gap-1 mb-3">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                ))}
              </div>
              <p 
                className="text-foreground/80 text-sm mb-4 line-clamp-3"
                style={{ fontFamily: 'Inter, sans-serif' }}
              >
                {`"${testimonial.content}"`}
              </p>
              <p className="text-foreground text-sm font-medium">{testimonial.name}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
