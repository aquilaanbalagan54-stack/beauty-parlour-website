"use client"

import { motion } from "framer-motion"
import { Instagram, Facebook, Twitter, Youtube, Phone, Mail, MapPin, Heart } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const footerLinks = {
  services: [
    { name: "Hair Services", href: "#services" },
    { name: "Beauty Treatments", href: "#services" },
    { name: "Bridal Makeup", href: "#bridal" },
    { name: "Korean Hair Wash", href: "#" },
    { name: "Grooming", href: "#services" },
  ],
  company: [
    { name: "About Us", href: "#about" },
    { name: "Gallery", href: "#gallery" },
    { name: "Testimonials", href: "#" },
    { name: "Contact", href: "#contact" },
    { name: "Book Now", href: "#booking" },
  ],
}

const socialLinks = [
  { icon: Instagram, href: "#", label: "Instagram" },
  { icon: Facebook, href: "#", label: "Facebook" },
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Youtube, href: "#", label: "YouTube" },
]

export function Footer() {
  return (
    <footer className="relative overflow-hidden">
      {/* Top border glow */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />

      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background to-secondary/20" />

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <a href="#" className="inline-block mb-6">
              <span className="text-3xl font-semibold text-gradient-gold">
                Naturallook
              </span>
            </a>
            <p 
              className="text-muted-foreground mb-6 leading-relaxed"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              {"Hosur's premium family salon delivering luxury beauty care, bridal transformations, and Korean hair wash experiences."}
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-full glass flex items-center justify-center text-foreground/70 hover:text-primary hover:border-primary/50 transition-all duration-300"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-foreground font-medium mb-6">Services</h4>
            <ul className="space-y-3">
              {footerLinks.services.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-muted-foreground hover:text-primary transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif' }}
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-foreground font-medium mb-6">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-muted-foreground hover:text-primary transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif' }}
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter & Contact */}
          <div>
            <h4 className="text-foreground font-medium mb-6">Stay Updated</h4>
            <p 
              className="text-muted-foreground mb-4 text-sm"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Subscribe for beauty tips and exclusive offers.
            </p>
            <form className="flex gap-2 mb-6">
              <Input
                type="email"
                placeholder="Your email"
                className="bg-secondary/50 border-border/50 focus:border-primary text-foreground placeholder:text-muted-foreground"
              />
              <Button className="burgundy-gradient text-primary-foreground shrink-0">
                Join
              </Button>
            </form>

            {/* Quick contact */}
            <div className="space-y-3 text-sm">
              <a 
                href="tel:+919688266300" 
                className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
                style={{ fontFamily: 'Inter, sans-serif' }}
              >
                <Phone className="w-4 h-4" />
                +91 96882 66300
              </a>
              <a 
                href="mailto:hello@naturallook.in" 
                className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
                style={{ fontFamily: 'Inter, sans-serif' }}
              >
                <Mail className="w-4 h-4" />
                hello@naturallook.in
              </a>
              <div 
                className="flex items-start gap-2 text-muted-foreground"
                style={{ fontFamily: 'Inter, sans-serif' }}
              >
                <MapPin className="w-4 h-4 shrink-0 mt-0.5" />
                <span>Hosur, Tamil Nadu, India</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-border/50">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p 
              className="text-muted-foreground text-sm"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              © 2026 Naturallook Family Salon & Bridal Studio. All Rights Reserved.
            </p>
            <p 
              className="text-muted-foreground text-sm flex items-center gap-1"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Made with <Heart className="w-4 h-4 text-accent fill-accent" /> in Hosur
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
