"use client"

import { motion } from "framer-motion"
import { Calendar, Clock, User, Phone, Mail, MessageSquare, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"

const services = [
  "Haircut & Styling",
  "Hair Spa",
  "Hair Coloring",
  "Korean Hair Wash",
  "Bridal Makeup",
  "Facial Treatment",
  "Waxing",
  "Grooming Package",
  "Other",
]

export function BookingSection() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    service: "",
    date: "",
    time: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In production, this would send to a backend
    const whatsappMessage = `Hi! I'd like to book an appointment.\n\nName: ${formData.name}\nPhone: ${formData.phone}\nService: ${formData.service}\nDate: ${formData.date}\nTime: ${formData.time}\nMessage: ${formData.message}`
    window.open(`https://wa.me/919688266300?text=${encodeURIComponent(whatsappMessage)}`, "_blank")
  }

  return (
    <section id="booking" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      
      {/* Decorative elements */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 left-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span 
            className="text-primary text-sm tracking-widest uppercase mb-4 block"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            Book Now
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-light mb-6">
            <span className="text-gradient-gold">Reserve Your</span>
            <br />
            <span className="text-foreground">Beauty Experience</span>
          </h2>
          <p 
            className="text-muted-foreground max-w-2xl mx-auto"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            Book your appointment now and let us pamper you with our premium beauty services.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <form onSubmit={handleSubmit} className="glass rounded-3xl p-8 md:p-10 space-y-6">
            {/* Name & Phone */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-foreground/80 text-sm flex items-center gap-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                  <User className="w-4 h-4 text-primary" />
                  Your Name
                </label>
                <Input
                  placeholder="Enter your name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-secondary/50 border-border/50 focus:border-primary text-foreground placeholder:text-muted-foreground"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-foreground/80 text-sm flex items-center gap-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                  <Phone className="w-4 h-4 text-primary" />
                  Phone Number
                </label>
                <Input
                  type="tel"
                  placeholder="+91 XXXXX XXXXX"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="bg-secondary/50 border-border/50 focus:border-primary text-foreground placeholder:text-muted-foreground"
                  required
                />
              </div>
            </div>

            {/* Email */}
            <div className="space-y-2">
              <label className="text-foreground/80 text-sm flex items-center gap-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                <Mail className="w-4 h-4 text-primary" />
                Email Address
              </label>
              <Input
                type="email"
                placeholder="your@email.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-secondary/50 border-border/50 focus:border-primary text-foreground placeholder:text-muted-foreground"
              />
            </div>

            {/* Service Selection */}
            <div className="space-y-2">
              <label className="text-foreground/80 text-sm flex items-center gap-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                <Sparkles className="w-4 h-4 text-primary" />
                Select Service
              </label>
              <select
                value={formData.service}
                onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                className="w-full h-10 px-3 rounded-md bg-secondary/50 border border-border/50 focus:border-primary text-foreground"
                style={{ fontFamily: 'Inter, sans-serif' }}
                required
              >
                <option value="">Choose a service</option>
                {services.map((service) => (
                  <option key={service} value={service}>
                    {service}
                  </option>
                ))}
              </select>
            </div>

            {/* Date & Time */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-foreground/80 text-sm flex items-center gap-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                  <Calendar className="w-4 h-4 text-primary" />
                  Preferred Date
                </label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="bg-secondary/50 border-border/50 focus:border-primary text-foreground"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-foreground/80 text-sm flex items-center gap-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                  <Clock className="w-4 h-4 text-primary" />
                  Preferred Time
                </label>
                <Input
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  className="bg-secondary/50 border-border/50 focus:border-primary text-foreground"
                  required
                />
              </div>
            </div>

            {/* Message */}
            <div className="space-y-2">
              <label className="text-foreground/80 text-sm flex items-center gap-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                <MessageSquare className="w-4 h-4 text-primary" />
                Additional Message
              </label>
              <Textarea
                placeholder="Any special requests or notes..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="bg-secondary/50 border-border/50 focus:border-primary text-foreground placeholder:text-muted-foreground min-h-[100px]"
              />
            </div>

            {/* Submit buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                type="submit"
                size="lg"
                className="flex-1 burgundy-gradient text-primary-foreground rounded-full glow-burgundy hover:scale-105 transition-transform"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Book via WhatsApp
              </Button>
              <Button
                type="button"
                size="lg"
                variant="outline"
                className="flex-1 border-primary/50 text-foreground rounded-full hover:bg-primary/10"
                asChild
              >
                <a href="tel:+919688266300">
                  <Phone className="w-5 h-5 mr-2" />
                  Call to Book
                </a>
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  )
}
