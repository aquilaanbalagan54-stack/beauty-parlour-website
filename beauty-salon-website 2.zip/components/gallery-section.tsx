"use client"

import { motion } from "framer-motion"
import { useState } from "react"

const galleryImages = [
  { src: "/api/placeholder/600/400", alt: "Bridal Makeup", category: "Bridal" },
  { src: "/api/placeholder/400/600", alt: "Hair Styling", category: "Hair" },
  { src: "/api/placeholder/600/400", alt: "Korean Hair Wash", category: "Korean" },
  { src: "/api/placeholder/400/400", alt: "Makeup Session", category: "Beauty" },
  { src: "/api/placeholder/600/400", alt: "Salon Interior", category: "Salon" },
  { src: "/api/placeholder/400/600", alt: "Hair Coloring", category: "Hair" },
  { src: "/api/placeholder/600/400", alt: "Bridal Hair", category: "Bridal" },
  { src: "/api/placeholder/400/400", alt: "Grooming", category: "Grooming" },
]

const categories = ["All", "Bridal", "Hair", "Beauty", "Korean", "Grooming", "Salon"]

export function GallerySection() {
  const [activeCategory, setActiveCategory] = useState("All")

  const filteredImages = activeCategory === "All" 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory)

  return (
    <section id="gallery" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span 
            className="text-primary text-sm tracking-widest uppercase mb-4 block"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            Our Work
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-light mb-6">
            <span className="text-gradient-gold">Beauty</span>
            <br />
            <span className="text-foreground">Gallery</span>
          </h2>
        </motion.div>

        {/* Category filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-5 py-2 rounded-full text-sm transition-all duration-300 ${
                activeCategory === category
                  ? "rose-gold-gradient text-primary-foreground"
                  : "glass text-foreground/80 hover:border-primary/50"
              }`}
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-4 space-y-4">
          {filteredImages.map((image, index) => (
            <motion.div
              key={`${image.alt}-${index}`}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.05 * index }}
              className="break-inside-avoid group relative overflow-hidden rounded-2xl"
            >
              {/* Placeholder for gallery images */}
              <div 
                className={`w-full bg-gradient-to-br from-secondary to-secondary/50 flex items-center justify-center ${
                  index % 3 === 1 ? 'aspect-[2/3]' : index % 3 === 2 ? 'aspect-square' : 'aspect-[3/2]'
                }`}
              >
                <div className="text-center p-4">
                  <div className="w-16 h-16 mx-auto rounded-full rose-gold-gradient flex items-center justify-center mb-3">
                    <span className="text-2xl text-primary-foreground">{image.category[0]}</span>
                  </div>
                  <p className="text-foreground/80 text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                    {image.alt}
                  </p>
                </div>
              </div>

              {/* Hover overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6">
                <span className="text-foreground font-medium" style={{ fontFamily: 'Inter, sans-serif' }}>
                  {image.alt}
                </span>
              </div>

              {/* Glow border on hover */}
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-primary/50 rounded-2xl transition-colors duration-300" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
