"use client"

import { motion } from "framer-motion"
import { MapPin, Phone, Clock, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ContactSection() {
  return (
    <section id="contact" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span 
            className="text-primary text-sm tracking-widest uppercase mb-4 block"
            style={{ fontFamily: 'Inter, sans-serif' }}
          >
            Visit Us
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-light mb-6">
            <span className="text-gradient-gold">Get in</span>
            <br />
            <span className="text-foreground">Touch</span>
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            {/* Address */}
            <div className="glass rounded-2xl p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl burgundy-gradient flex items-center justify-center shrink-0">
                <MapPin className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h3 className="text-foreground font-medium mb-2">Our Location</h3>
                <p className="text-muted-foreground" style={{ fontFamily: 'Inter, sans-serif' }}>
                  PRWM+HHG, Bagalur Rd, opp. Nggo&apos;s Busstop,
                  <br />
                  Hosur, Avalapalli Hudco, Tamil Nadu 635109, India
                </p>
              </div>
            </div>

            {/* Phone */}
            <div className="glass rounded-2xl p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl burgundy-gradient flex items-center justify-center shrink-0">
                <Phone className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h3 className="text-foreground font-medium mb-2">Phone Number</h3>
                <a 
                  href="tel:+919688266300" 
                  className="text-primary hover:text-primary/80 transition-colors text-lg"
                  style={{ fontFamily: 'Inter, sans-serif' }}
                >
                  +91 96882 66300
                </a>
              </div>
            </div>

            {/* Hours */}
            <div className="glass rounded-2xl p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl burgundy-gradient flex items-center justify-center shrink-0">
                <Clock className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h3 className="text-foreground font-medium mb-2">Working Hours</h3>
                <p className="text-muted-foreground" style={{ fontFamily: 'Inter, sans-serif' }}>
                  Open Daily
                  <br />
                  8:00 AM – 9:30 PM
                </p>
              </div>
            </div>

            {/* CTA buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                size="lg"
                className="flex-1 burgundy-gradient text-primary-foreground rounded-full glow-burgundy hover:scale-105 transition-transform"
                asChild
              >
                <a href="https://wa.me/919688266300" target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  WhatsApp Us
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="flex-1 border-primary/50 text-foreground rounded-full hover:bg-primary/10"
                asChild
              >
                <a href="tel:+919688266300">
                  <Phone className="w-5 h-5 mr-2" />
                  Call Now
                </a>
              </Button>
            </div>
          </motion.div>

          {/* Map */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass rounded-3xl overflow-hidden h-[400px] lg:h-full min-h-[400px]"
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3889.8892!2d77.8271!3d12.7404!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTLCsDQ0JzI1LjQiTiA3N8KwNDknMzcuNiJF!5e0!3m2!1sen!2sin!4v1234567890"
              width="100%"
              height="100%"
              style={{ border: 0, filter: "invert(90%) hue-rotate(180deg)" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Naturallook Salon Location"
            />
          </motion.div>
        </div>
      </div>
    </section>
  )
}
